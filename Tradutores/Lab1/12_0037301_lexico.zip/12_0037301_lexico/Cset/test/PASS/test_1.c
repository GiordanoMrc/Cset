int main(){
    int a_1;
    writeln("Hello World");
    return 0;
}