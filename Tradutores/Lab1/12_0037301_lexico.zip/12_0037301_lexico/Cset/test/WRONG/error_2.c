int main(){
    int 1%;
    writeln("Hello World");
    return 0;
}