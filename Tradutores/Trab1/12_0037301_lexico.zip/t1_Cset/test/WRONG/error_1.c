int main(){
    int 1_!a;
    set $x;
    writeln("Hello World"@);

    return 0;
}