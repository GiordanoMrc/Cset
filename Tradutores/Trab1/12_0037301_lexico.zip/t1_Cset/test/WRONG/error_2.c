int main(){
    set ?;
    writeln("Hello World"##);
    return 0;
}